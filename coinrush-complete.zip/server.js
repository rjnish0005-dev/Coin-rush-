const express=require("express"),http=require("http"),path=require("path");
const session=require("express-session"),bcrypt=require("bcryptjs"),Database=require("better-sqlite3");
const {Server}=require("socket.io"),crypto=require("crypto");
const app=express(),server=http.createServer(app),io=new Server(server);
const db=new Database("coinrush.db");
db.exec(`CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT UNIQUE NOT NULL,password TEXT NOT NULL,role TEXT NOT NULL DEFAULT 'player',balance INTEGER NOT NULL DEFAULT 10000,active INTEGER NOT NULL DEFAULT 1,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS rounds(id INTEGER PRIMARY KEY AUTOINCREMENT,status TEXT NOT NULL,start_at INTEGER NOT NULL,end_at INTEGER NOT NULL,result TEXT);
CREATE TABLE IF NOT EXISTS bets(id INTEGER PRIMARY KEY AUTOINCREMENT,round_id INTEGER,user_id INTEGER,side TEXT,amount INTEGER,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS ledger(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,amount INTEGER,type TEXT,reason TEXT,admin_id INTEGER,round_id INTEGER,created_at TEXT DEFAULT CURRENT_TIMESTAMP);`);
if(!db.prepare("SELECT 1 FROM users WHERE role='admin'").get()){
 const hash=bcrypt.hashSync("admin123",10);
 db.prepare("INSERT INTO users(username,password,role) VALUES(?,?,?)").run("admin",hash,"admin");
}
app.use(express.json());app.use(express.static(path.join(__dirname,"public")));
app.use(session({secret:process.env.SESSION_SECRET||"change-this-secret",resave:false,saveUninitialized:false,cookie:{httpOnly:true,sameSite:"lax"}}));

function user(req,res,next){if(!req.session.user)return res.status(401).json({error:"Login required"});next()}
function admin(req,res,next){if(!req.session.user||req.session.user.role!=="admin")return res.status(403).json({error:"Admin only"});next()}
function currentRound(){
 let r=db.prepare("SELECT * FROM rounds ORDER BY id DESC LIMIT 1").get();
 if(!r||Date.now()>=r.end_at){const now=Date.now();const info=db.prepare("INSERT INTO rounds(status,start_at,end_at) VALUES('open',?,?)").run(now,now+30000);r=db.prepare("SELECT * FROM rounds WHERE id=?").get(info.lastInsertRowid);}
 return r;
}
app.post("/api/login",(req,res)=>{const u=db.prepare("SELECT * FROM users WHERE username=?").get(req.body.username||"");if(!u||!u.active||!bcrypt.compareSync(req.body.password||"",u.password))return res.status(401).json({error:"Invalid login"});req.session.user={id:u.id,username:u.username,role:u.role};res.json(req.session.user)});
app.post("/api/logout",(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get("/api/me",user,(req,res)=>{const u=db.prepare("SELECT id,username,role,balance,active FROM users WHERE id=?").get(req.session.user.id);res.json(u)});
app.get("/api/round",user,(req,res)=>{const r=currentRound();const own=db.prepare("SELECT side,amount FROM bets WHERE round_id=? AND user_id=?").all(r.id,req.session.user.id);res.json({round:r,own})});
app.post("/api/bet",user,(req,res)=>{
 const r=currentRound(), side=req.body.side, amount=Number(req.body.amount), uid=req.session.user.id;
 if(r.status!=="open"||Date.now()>r.end_at-5000)return res.status(400).json({error:"Betting locked"});
 if(!["HEADS","TAILS"].includes(side)||!Number.isInteger(amount)||amount<1)return res.status(400).json({error:"Invalid bet"});
 const tx=db.transaction(()=>{const u=db.prepare("SELECT balance FROM users WHERE id=?").get(uid);if(u.balance<amount)throw Error("Insufficient coins");
 db.prepare("UPDATE users SET balance=balance-? WHERE id=?").run(amount,uid);
 db.prepare("INSERT INTO bets(round_id,user_id,side,amount) VALUES(?,?,?,?)").run(r.id,uid,side,amount);
 db.prepare("INSERT INTO ledger(user_id,amount,type,reason,round_id) VALUES(?,?,?,?,?)").run(uid,-amount,"BET_RESERVE","Game entry",r.id);});try{tx()}catch(e){return res.status(400).json({error:e.message})}io.emit("public_stats",stats(r.id));res.json({ok:true});
});
function stats(id){return {round_id:id,...db.prepare("SELECT COALESCE(SUM(CASE WHEN side='HEADS' THEN amount ELSE 0 END),0) heads,COALESCE(SUM(CASE WHEN side='TAILS' THEN amount ELSE 0 END),0) tails,COUNT(DISTINCT user_id) players FROM bets WHERE round_id=?").get(id)}}
app.get("/api/admin/users",admin,(req,res)=>res.json(db.prepare("SELECT id,username,role,balance,active,created_at FROM users ORDER BY id DESC").all()));
app.post("/api/admin/users/:id/coins",admin,(req,res)=>{const amount=Number(req.body.amount),reason=req.body.reason||"Admin adjustment",uid=Number(req.params.id);if(!Number.isInteger(amount)||amount===0)return res.status(400).json({error:"Invalid amount"});const tx=db.transaction(()=>{const u=db.prepare("SELECT balance FROM users WHERE id=?").get(uid);if(!u)throw Error("User not found");if(u.balance+amount<0)throw Error("Balance cannot be negative");db.prepare("UPDATE users SET balance=balance+? WHERE id=?").run(amount,uid);db.prepare("INSERT INTO ledger(user_id,amount,type,reason,admin_id) VALUES(?,?,?,?,?)").run(uid,amount,amount>0?"ADMIN_CREDIT":"ADMIN_DEBIT",reason,req.session.user.id)});try{tx()}catch(e){return res.status(400).json({error:e.message})}res.json({ok:true})});
app.get("/api/admin/ledger",admin,(req,res)=>res.json(db.prepare("SELECT l.*,u.username FROM ledger l JOIN users u ON u.id=l.user_id ORDER BY l.id DESC LIMIT 200").all()));
app.get("/api/admin/stats",admin,(req,res)=>res.json(stats(currentRound().id)));
app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));

let lastProcessed=0;
setInterval(()=>{
 const r=currentRound(); if(Date.now()<r.end_at||r.id===lastProcessed)return;
 lastProcessed=r.id;
 const result=crypto.randomInt(0,2)?"HEADS":"TAILS";
 db.prepare("UPDATE rounds SET status='closed',result=? WHERE id=?").run(result,r.id);
 // Fair demo settlement: winners receive their reserved amount back (no monetary payout).
 const winners=db.prepare("SELECT user_id,amount FROM bets WHERE round_id=? AND side=?").all(r.id,result);
 const tx=db.transaction(()=>{for(const b of winners){db.prepare("UPDATE users SET balance=balance+? WHERE id=?").run(b.amount,b.user_id);db.prepare("INSERT INTO ledger(user_id,amount,type,reason,round_id) VALUES(?,?,?,?,?)").run(b.user_id,b.amount,"ROUND_SETTLEMENT","Winning virtual points returned",r.id)}});
 tx();io.emit("round_result",{round:r.id,result});io.emit("public_stats",stats(r.id));
},250);
io.on("connection",s=>{s.emit("public_stats",stats(currentRound().id));});
server.listen(process.env.PORT||3000,()=>console.log("CoinRush on http://localhost:"+ (process.env.PORT||3000)));
